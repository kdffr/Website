const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const fs = require('fs');
const path = require('path');

const app = express();
const port = 3000;

// 中间件
app.use(bodyParser.json());
app.use(cors());

// 存储用户数据的文件路径
const usersFilePath = path.join(__dirname, 'users.json');

// 从文件读取用户数据
function readUsers() {
    if (!fs.existsSync(usersFilePath)) {
        return {};
    }
    const data = fs.readFileSync(usersFilePath, 'utf8');
    return JSON.parse(data);
}

// 保存用户数据到文件
function writeUsers(users) {
    fs.writeFileSync(usersFilePath, JSON.stringify(users, null, 2), 'utf8');
}

// 登录路由
app.post('/login', (req, res) => {
    const { username, password } = req.body;
    const users = readUsers();

    if (users[username] && users[username] === password) {
        res.send('登录成功');
    } else {
        res.send('用户名或密码错误');
    }
});

// 注册路由
app.post('/register', (req, res) => {
    const { username, password } = req.body;
    const users = readUsers();

    if (users[username]) {
        res.send('用户名已存在');
    } else {
        users[username] = password;
        writeUsers(users);
        res.send('注册成功');
    }
});

// 静态文件服务
app.use(express.static('public'));

// 启动服务器
app.listen(port, () => {
    console.log(`Server running on port ${port}`);
});
